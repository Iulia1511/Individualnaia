<?php
session_start();

if (isset($_GET['answer']) && ($_GET['answer'] == 'да' || $_GET['answer'] == 'нет')) {
    $answer = $_GET['answer'];

    // Подключение к базе данных
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "myDB";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Запись ответа в базу данных
    $sql = "INSERT INTO voiting_db (question, answer) VALUES ('Голосование', '$answer')";

    if ($conn->query($sql) === TRUE) {
        // Запись прошла успешно
        echo "Ваш ответ '$answer' был успешно записан!";
    } else {
        echo "Ошибка: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
} else {
    echo "Недопустимый ответ!";
}
?>
