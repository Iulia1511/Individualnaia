<!DOCTYPE html>
<html>
<head>
    <title>Добро пожаловать</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f7f7;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="password"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .footer {
            text-align: center;
            margin-top: 50px;
            color: #45a049;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .admin-link {
            font-size: 16px;
            font-weight: bold;
            position: absolute;
            left: 20px;
            top: 20px;
            text-decoration: none;
            color: #333;
        }
        .admin-link:hover {
            color: #555;
        }
    </style>
</head>
<body>
<a href="admin_login.php" class="admin-link">Администратор</a>

    <div class="container">
        <h2>Добро пожаловать</h2>
        <h3>Регистрация</h3>
        <form action="register_process.php" method="post">
            <label for="username">Имя пользователя:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Пароль:</label>
            <input type="password" id="password" name="password" required>
            <input type="submit" value="Зарегистрироваться">
        </form>
        <h3>Вход</h3>
        <form action="login_process.php" method="post">
            <label for="login_username">Имя пользователя:</label>
            <input type="text" id="login_username" name="username" required>
            <label for="login_password">Пароль:</label>
            <input type="password" id="login_password" name="password" required>
            <input type="submit" value="Войти">
        </form>
    </div>
    <div class="footer">
        <?php echo date('Y'); ?> Obsudim?
    </div>
</body>
</html>

