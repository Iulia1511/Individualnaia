<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>О нас - Obsudim?</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            font-family: 'Arial Black', sans-serif;
            color: #333;
        }
        p {
            margin-bottom: 20px;
            font-size: 16px;
        }
        .rating {
            text-align: center;
            margin-top: 40px;
        }
        .rating label {
            margin-right: 10px;
            font-weight: bold;
        }
        .rating input[type="radio"] {
            display: none;
        }
        .rating input[type="radio"] + label:before {
            content: '★';
            margin-right: 5px;
            color: #ddd;
        }
        .rating input[type="radio"]:checked + label:before {
            color: #ff9800;
        }
        .vote-message {
            text-align: center;
            margin-top: 20px;
            padding: 10px;
            background-color: #4caf50;
            color: #fff;
            border-radius: 5px;
            display: none; /* Сначала скрываем сообщение */
        }
    </style>
</head>
<body>
    <?php
    include 'menu.php';
    ?>
    <div class="container">
        <h1>Добро пожаловать на страницу Obsudim?</h1>
        <p>Рады приветствовать вас в нашем онлайн сообществе, где каждый голос имеет значение. Наша миссия - создать пространство для открытого общения, обмена мнениями и идеями.</p>
        <p>Что делает наше сообщество уникальным? Мы предлагаем регулярные рандомные голосования по различным темам, чтобы вы могли высказывать свое мнение и видеть, что думают другие участники. Наша платформа поощряет разнообразие мнений и уважительный диалог между участниками.</p>
        <p>Здесь вы можете обсудить самые разные темы - от политики и науки до культуры и развлечений. Наша цель - сделать общение интересным, познавательным и вдохновляющим для всех участников.</p>
        <p>Мы уверены, что каждый человек имеет право на свое мнение, и поэтому наша платформа открыта для всех без исключения. Мы приветствуем разнообразие и приглашаем всех желающих присоединиться к обсуждениям и голосованиям.</p>
        <p>Присоединяйтесь к нам сегодня и внесите свой вклад в формирование открытого и взаимопонимающегося сообщества! Вместе мы можем достичь большего и сделать наш мир лучше.</p>
        
        <div class="rating">
            <p>Оцените наш сайт от 1 до 10:</p>
            <form id="vote-form" action="vote.php" method="post">
                <?php for ($i = 1; $i <= 10; $i++): ?>
                    <input type="radio" id="rating<?php echo $i; ?>" name="rating" value="<?php echo $i; ?>">
                    <label for="rating<?php echo $i; ?>"><?php echo $i; ?></label>
                <?php endfor; ?>
                <input type="submit" value="Голосовать">
            </form>
            <!-- Сообщение о сохранении голоса -->
            <div id="vote-message" class="vote-message">Ваш голос был успешно учтен!</div>
        </div>
    </div>

    <script>
        document.getElementById("vote-form").addEventListener("submit", function(event) {
            event.preventDefault(); // Предотвращаем отправку формы
            var xhr = new XMLHttpRequest();
            xhr.open("POST", this.action, true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    // Показываем сообщение о сохранении голоса
                    document.getElementById("vote-message").style.display = "block";
                }
            };
            xhr.send(new FormData(this));
        });
    </script>
</body>
</html>
