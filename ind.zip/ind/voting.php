<?php
function getRandomQuestion() {
    $questions = array(
        "Согласны ли вы с предложением?",
        "Поддерживаете ли вы идею?",
        "Считаете ли вы важным?",
        "Понравилось ли?",
        "Это круто?",
        "Интересно ли вам это?",
        "Можно ли присоедениться?",
        "Нужно ли вам?"

    );

    $randomIndex = array_rand($questions);
    return $questions[$randomIndex];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Голосование - Obsudim?</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        nav {
            text-align: center;
            margin-bottom: 20px;
            background-color: #4caf50;
            font-size: 20px;
            padding: 10px 0;
        }
        nav a {
            margin: 0 10px;
            text-decoration: none;
            color: #fff;
            font-weight: bold;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            font-family: 'Arial Black', sans-serif;
            color: #333;
        }
        .question {
            margin-bottom: 20px;
        }
        .question h2 {
            font-size: 24px;
            text-align: center;
            margin-bottom: 20px;
        }
        .answer-btns {
            text-align: center;
        }
        .answer-btn {
            display: inline-block;
            width: 100px;
            margin: 0 10px;
            padding: 10px;
            background-color: #4caf50;
            color: #fff;
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .answer-btn:hover {
            background-color: #45a049;
        }
        .logout-btn {
            display: block;
            width: 100px;
            margin: 20px auto 0;
            padding: 10px;
            background-color: #f44336;
            color: #fff;
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }
        .success-message {
            text-align: center;
            margin-top: 20px;
            padding: 10px;
            background-color: #4caf50;
            color: #fff;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <nav>
        <a href="about.php">О нас</a>
        <a href="voting.php">Голосование</a>
        <a href="comment_page.php">Обсуждение</a>
    </nav>
    <div class="container">
        <h1>Obsudim?</h1>
        <div class="question">
            <h2>Вопрос: <?php echo getRandomQuestion(); ?></h2>
            <div class="answer-btns">
                <button class="answer-btn" onclick="vote('да')">Да</button>
                <button class="answer-btn" onclick="vote('нет')">Нет</button>
            </div>
        </div>
        <button class="logout-btn" onclick="logout()">Выйти</button>
        <div id="successMessage" class="success-message" style="display: none;">Ваш ответ был успешно записан!</div>
    </div>

    <script>
        function vote(answer) {
            // Эмуляция отправки данных на сервер и отображение сообщения об успехе
            setTimeout(function() {
                document.getElementById('successMessage').style.display = 'block';
            }, 1000);
        }
        
        function logout() {
            window.location.href = 'logout.php';
        }
    </script>
</body>
</html>

