<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Голосование - Obsudim?</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        nav {
            text-align: center;
            margin-bottom: 20px;
            background-color: #4caf50;
            font-size: 20px;
            padding: 10px 0;
        }
        nav a {
            margin: 0 10px;
            text-decoration: none;
            color: #fff;
            font-weight: bold;
        }
    
        h1 {
            text-align: center;
            font-family: 'Arial Black', sans-serif;
            color: #333;
        }
      
       
     
    </style>
</head>
<body>
    <nav>
        <a href="about.php">О нас</a>
        <a href="voting.php">Голосование</a>
        <a href="comment_page.php">Обсуждение</a>
    </nav>