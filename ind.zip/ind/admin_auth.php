<?php
// Проверка введенного пользователем логина и пароля (пример)
$validUsername = 'admin';
$validPassword = 'admin123';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === $validUsername && $password === $validPassword) {
        $validUsername = 'admin'; 
$validPassword = 'admin123'; 

        // Устанавливаем сессию для администратора
        session_start();
        $_SESSION['admin'] = true;
        header("Location: admin_upload.php");
        exit();
    } else {
        echo "Неверное имя пользователя или пароль.";
    }
}
?>
