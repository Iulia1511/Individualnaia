<?php
session_start(); // Начинаем сессию

$imagePath = isset($_SESSION['imagePath']) ? $_SESSION['imagePath'] : ""; // Получаем путь к изображению

include 'menu.php'; // Подключаем меню
?>
<!DOCTYPE html>
<html>
<head>
    <title>Страница с изображением и комментариями - Obsudim?</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
        }
        img {
            display: block;
            margin: 0 auto;
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }
        .comment-form {
            margin-top: 20px;
            text-align: center;
        }
        .comment-form textarea {
            width: 100%;
            max-width: 100%;
            height: 100px;
            padding: 10px;
            box-sizing: border-box;
            border-radius: 5px;
            border: 1px solid #ccc;
            resize: none;
        }
        .comment-form input[type="submit"] {
            padding: 10px 20px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .comment-form input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Изображение</h1>
        <img src="<?php echo $imagePath; ?>" alt="Uploaded Image">

        <div class="comment-form">
            <h2>Оставьте комментарий</h2>
            <form action="comment_process.php" method="post">
                <textarea name="comment" placeholder="Напишите свой комментарий здесь" required></textarea><br>
                <input type="submit" value="Отправить комментарий">
            </form>
        </div>
    </div>
</body>
</html>
