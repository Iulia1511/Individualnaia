<?php
// Подключение к базе данных
$servername = "localhost";
$username = "root"; // Замените на ваше имя пользователя базы данных
$password = ""; // Замените на ваш пароль базы данных
$dbname = "myDB"; // Замените на ваше имя базы данных

// Создание подключения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка подключения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Обработка отправленного комментария
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["comment"])) {
    $comment = $_POST["comment"];

    // Подготовка запроса на вставку комментария в базу данных
    $sql = "INSERT INTO comments (comment_text) VALUES (?)";

    // Подготовка запроса с использованием подготовленных выражений
    if ($stmt = $conn->prepare($sql)) {
        // Привязка параметров и выполнение запроса
        $stmt->bind_param("s", $comment);
        $stmt->execute();

        // Закрытие подготовленного выражения
        $stmt->close();

        // Редирект на страницу с комментариями после отправки
        header("Location: comment_page.php");
    } else {
        echo "Ошибка подготовки запроса: " . $conn->error;
    }
} else {
    // Если комментарий не был отправлен, перенаправляем на страницу с комментариями
    header("Location: comment_page.php");
}

// Закрытие соединения с базой данных
$conn->close();
?>
