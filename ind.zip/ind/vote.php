<?php
// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myDB";

// Создание подключения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение значения голоса
if(isset($_POST['rating'])) {
    $rating = $_POST['rating'];

    // Подготовленный запрос для вставки голоса в базу данных
    $stmt = $conn->prepare("INSERT INTO ratings (rating) VALUES (?)");
    $stmt->bind_param("i", $rating);

    // Выполнение запроса
    if ($stmt->execute()) {
        echo "Ваш голос был успешно учтен!";
    } else {
        echo "Ошибка: " . $conn->error;
    }

    // Закрытие подготовленного запроса и соединения
    $stmt->close();
    $conn->close();
} else {
    echo "Неверный запрос!";
}
?>
