<?php
session_start();
// Проверка наличия сессии
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Добро пожаловать</title>
</head>
<body>
    <?php
        include 'voting.php';
?>
</body>
</html>
