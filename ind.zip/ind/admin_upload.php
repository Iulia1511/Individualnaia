<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["image"])) {
    $targetDir = "uploads/";
    $targetFile = $targetDir . basename($_FILES["image"]["name"]);

    if (file_exists($targetFile)) {
        echo "Файл с таким именем уже существует.";
        exit();
    }

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
        $_SESSION['imagePath'] = $targetFile;
        echo "Изображение успешно загружено.";
    } else {
        echo "Ошибка при загрузке изображения.";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Загрузка изображения - Obsudim?</title>
</head>
<body>
    <?php if ($_SESSION['admin']): ?>
    <h1>Загрузка изображения</h1>
    <form action="admin_upload.php" method="post" enctype="multipart/form-data">
        <input type="file" name="image" accept="image/*" required>
        <input type="submit" value="Загрузить">
    </form>
    <?php else: ?>
    <p>У вас нет прав доступа к этой странице.</p>
    <?php endif; ?>
    <form action="logout.php" method="post">
        <input type="submit" value="Выйти">
    </form>
</body>
</html>
