<?php
// Проверяем, является ли пользователь администратором (может быть реализовано другим способом)
$isAdmin = true; // Здесь нужно провести проверку аутентификации администратора

if ($isAdmin && isset($_FILES['image'])) {
    $uploadDir = 'uploads/'; // Директория для загрузки изображений
    $uploadFile = $uploadDir . basename($_FILES['image']['name']);

    // Проверяем, является ли загруженный файл изображением
    $imageType = strtolower(pathinfo($uploadFile, PATHINFO_EXTENSION));
    if (getimagesize($_FILES['image']['tmp_name']) !== false) {
        // Перемещаем файл в директорию загрузки
        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
            echo "Изображение успешно загружено.";
            // Здесь можно сохранить путь к изображению в базе данных или как-то еще обработать
        } else {
            echo "Ошибка при загрузке изображения.";
        }
    } else {
        echo "Файл не является изображением.";
    }
} else {
    echo "У вас нет прав доступа к этой странице или изображение не было загружено.";
}
?>
