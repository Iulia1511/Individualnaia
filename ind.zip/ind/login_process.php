<?php
session_start();
// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myDB";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение данных из формы
$username = $_POST['username'];
$password = $_POST['login_password']; // Изменено с 'password' на 'login_password'

// Хеширование пароля

// Поиск пользователя в базе данных
$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Успешный вход, создание сессии
    $_SESSION['username'] = $username;
    header("Location: welcome.php");
} else {
    echo "Неверное имя пользователя или пароль";
}

$conn->close();
?>
